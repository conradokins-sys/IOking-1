package com.ioking.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView webView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        // Le jeu est une page unique (SPA) : on laisse index.html décider de la navigation
        // (fermer une fenêtre, quitter une partie, revenir à l'accueil) avant de fermer
        // l'application. Auparavant, le bouton retour fermait l'app brutalement.
        webView.evaluateJavascript(
            "(function(){ return (typeof backPressed === 'function') ? backPressed() : false; })();",
            (ValueCallback<String>) handled -> {
                if (!"true".equals(handled)) {
                    MainActivity.super.onBackPressed();
                }
            }
        );
    }
}
