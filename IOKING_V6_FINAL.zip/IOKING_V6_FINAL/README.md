# IOKing V6

Version Android du jeu IOKing avec :
- partie hors ligne contre IA
- partie hors ligne à deux joueurs
- partie en ligne P2P via PeerJS (code de joueur à partager)
- profil persistant : victoires, défaites, points et rang
- victoire = +10 points ; défaite = −4 points (3 min), −2 points (5 min), −1 point (10 min)
- rangs : Débutant, Normal, Intermédiaire, Difficile, Maître, Grand maître, Stratège, Maître stratège
- icône officielle IOKing V6 intégrée

## Construire l'APK
Le dépôt est prêt pour GitHub Actions. Le workflow `.github/workflows/build-apk.yml` lance `assembleDebug` et publie l'APK.

## Jeu en ligne
La connexion P2P nécessite Internet et utilise le service de signalisation PeerJS chargé depuis un CDN. Le code affiché dans « Créer une partie » doit être partagé avec l'adversaire, qui le saisit dans « Rejoindre une partie ». Le plateau de départ est recalculé localement par chaque appareil (jamais transmis), et chaque coup reçu est revalidé avant d'être appliqué, ce qui empêche un adversaire de tricher en envoyant un coup ou un plateau invalide.

## Changelog V6.1
Corrections et améliorations apportées à la version précédente :
- **Points** : le README indiquait à tort « défaite = +2 points » alors que le jeu appliquait déjà un malus selon la durée ; la documentation est maintenant cohérente avec le code.
- **Bug de blocage** : si un joueur (notamment l'IA) n'avait plus aucun coup possible, la partie restait bloquée sans fin. Un joueur sans coup légal perd désormais automatiquement la partie.
- **Bug victoire/défaite en ligne** : un joueur ayant rejoint une partie en tant que Noir voyait parfois l'écran « Défaite » alors qu'il venait de gagner (le calcul supposait à tort que l'utilisateur jouait toujours Blanc). Chaque joueur juge maintenant le résultat selon sa propre couleur.
- **Sécurité en ligne / anti-triche** : le jeu ne transmet plus l'état complet du plateau (facilement falsifiable) mais uniquement des coups individuels, revalidés par le destinataire avant application.
- **IA améliorée** : l'IA évite désormais les captures qui exposent inutilement une pièce, protège son Cœur, et privilégie les prises de valeur plutôt qu'un choix quasi aléatoire.
- **Bouton retour Android** : il navigue maintenant dans le jeu (quitter une partie, fermer une fenêtre, revenir à l'accueil) au lieu de fermer l'application brutalement.
- **Messages réseau** : les erreurs de connexion (code introuvable, adversaire hors ligne, problème réseau) affichent désormais un message clair en français plutôt qu'un code technique.
